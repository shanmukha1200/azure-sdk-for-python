# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azure.ai.agentserver.core._platform_headers import SESSION_ID as _SESSION_ID  # pylint: disable=import-error,no-name-in-module


class InvocationConstants:
    """Invocation protocol constants.

    Protocol-specific headers, env vars, and defaults for the invocation
    endpoints.  Cross-cutting header names (e.g. session ID) are imported
    from :mod:`azure.ai.agentserver.core._platform_headers`.
    """

    # Request / response headers
    INVOCATION_ID_HEADER = "x-agent-invocation-id"
    SESSION_ID_HEADER = _SESSION_ID

    # Span attribute keys
    ATTR_SPAN_INVOCATION_ID = "azure.ai.agentserver.invocations.invocation_id"
    ATTR_SPAN_SESSION_ID = "azure.ai.agentserver.invocations.session_id"
    ATTR_SPAN_ERROR_CODE = "azure.ai.agentserver.invocations.error.code"
    ATTR_SPAN_ERROR_MESSAGE = "azure.ai.agentserver.invocations.error.message"


class InvocationsWSConstants:
    """invocations_ws (WebSocket) protocol constants.

    Route, structured-log field keys, and close codes for the WebSocket
    endpoint hosted alongside the HTTP invocations protocol.
    """

    # Route
    ROUTE_PATH = "/invocations_ws"

    # Close codes (RFC 6455)
    CLOSE_NORMAL = 1000  # handler returned cleanly
    CLOSE_INTERNAL_ERROR = 1011  # handler raised an unhandled exception

    # Structured-log ``extra`` keys.
    ATTR_SPAN_SESSION_ID = "azure.ai.agentserver.invocations_ws.session_id"
    ATTR_SPAN_CLOSE_CODE = "azure.ai.agentserver.invocations_ws.close_code"
    ATTR_SPAN_DURATION_MS = "azure.ai.agentserver.invocations_ws.duration_ms"
    ATTR_SPAN_ERROR_CODE = "azure.ai.agentserver.invocations_ws.error.code"
